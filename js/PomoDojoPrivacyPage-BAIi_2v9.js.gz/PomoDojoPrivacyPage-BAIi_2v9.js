import{j as e}from"./index-BZVjm5lD.js";import{S as o}from"./chunk-Bm3EnXv7.js";import"./chunk-DavUf6mE.js";import"./chunk-B_LIVuzY.js";import"./chunk-CQJNJhC9.js";const i=`<div class="pomo-legal">
<h1>PomoDojo - Pomodoro Timer Privacy Policy</h1>
<strong>Privacy Policy</strong>
<p>This privacy policy is applicable to the PomoDojo - Pomodoro Timer app (hereinafter referred to
    as "Application") for mobile devices, which was developed by Fakhry Mubarak (hereinafter
    referred to as "Service Provider") as a a Free service. This service is provided "AS IS".</p>
<br><strong>What information does the Application obtain and how is it used?</strong><br><strong>What
    information do users provide to the Application?</strong>
<p>The Application acquires the information you supply when you download and register the
    Application. Registration with the Service Provider is not mandatory. However, bear in mind that
    you might not be able to utilize some of the features offered by the Application unless you
    register with them.</p>
<p>The Service Provider may also use the information you provided them to contact you from time to
    time to provide you with important information, required notices and marketing promotions.</p>
<br><strong>What information does the Application collect automatically?</strong>
<p>In addition, the Application may collect certain information automatically, including, but not
    limited to, the type of mobile device you use, your mobile devices unique device ID, the IP
    address of your mobile device, your mobile operating system, the type of mobile Internet
    browsers you use, and information about the way you use the Application.</p><br><strong>Does the
    Application collect precise real time location information of the device?</strong>
<p>This Application does not gather precise information about the location of your mobile
    device.</p>
<div style="display: none;"><p>This Application collects your device's location, which helps the
    Service Provider determine your approximate geographical location and make use of in below
    ways:</p>
    <ul>
        <li>Geolocation Services: The Service Provider utilizes location data to provide features
            such as personalized content, relevant recommendations, and location-based services.
        </li>
        <li>Analytics and Improvements: Aggregated and anonymized location data helps the Service
            Provider to analyze user behavior, identify trends, and improve the overall performance
            and functionality of the Application.
        </li>
        <li>Third-Party Services: Periodically, the Service Provider may transmit anonymized
            location data to external services. These services assist them in enhancing the
            Application and optimizing their offerings.
        </li>
    </ul>
</div>
<br><strong>Does the Application use Artificial Intelligence (AI) technologies?</strong>
<p>The Application does not use Artificial Intelligence (AI) technologies to process your data or
    provide features.</p>
<div style="display: none;"><p>The Application uses Artificial Intelligence (AI) technologies to
    enhance user experience and provide certain features. The AI components may process user data in
    the following ways:</p>
    <ul>
        <li>Personalized Content: AI may analyze your usage patterns to deliver content tailored to
            your preferences and behavior.
        </li>
        <li>Recommendations: AI may suggest features, services, or content based on your
            interactions within the Application.
        </li>
        <li>Automated Functionalities: Certain app features may be powered by AI to automate tasks
            or improve efficiency.
        </li>
        <li>Data Protection: All AI processing is performed in accordance with this privacy policy
            and applicable laws, ensuring your data is handled securely and responsibly.
        </li>
    </ul>
</div>
<br><strong>Do third parties see and/or have access to information obtained by the
    Application?</strong>
<p>Only aggregated, anonymized data is periodically transmitted to external services to aid the
    Service Provider in improving the Application and their service. The Service Provider may share
    your information with third parties in the ways that are described in this privacy
    statement.</p>
<div><br>
    <p>Please note that the Application utilizes third-party services that have their own Privacy
        Policy about handling data. Below are the links to the Privacy Policy of the third-party
        service providers used by the Application:</p>
    <ul>
        <li><a href="https://firebase.google.com/support/privacy/" target="_blank"
               rel="noopener noreferrer">Firebase Crashlytics</a></li>
    </ul>
</div>
<p>The Service Provider may disclose User Provided and Automatically Collected Information:</p>
<ul>
    <li>as required by law, such as to comply with a subpoena, or similar legal process;</li>
    <li>when they believe in good faith that disclosure is necessary to protect their rights,
        protect your safety or the safety of others, investigate fraud, or respond to a government
        request;
    </li>
    <li>with their trusted services providers who work on their behalf, do not have an independent
        use of the information we disclose to them, and have agreed to adhere to the rules set forth
        in this privacy statement.
    </li>
</ul>
<p></p><br><strong>What are my opt-out rights?</strong>
<p>You can halt all collection of information by the Application easily by uninstalling the
    Application. You may use the standard uninstall processes as may be available as part of your
    mobile device or via the mobile application marketplace or network.</p><br><strong>What is the
    data retention policy and how can you manage your information?</strong>
<p>The Service Provider will retain User Provided data for as long as you use the Application and
    for a reasonable time thereafter. The Service Provider will retain Automatically Collected
    information for up to 24 months and thereafter may store it in aggregate. If you'd like the
    Service Provider to delete User Provided Data that you have provided via the Application, please
    contact them at fakhrymubarak@gmail.com and we will respond in a reasonable time. Please note
    that some or all of the User Provided Data may be required in order for the Application to
    function properly.</p><br><strong>How does the Application address children's privacy?</strong>
<p>The Service Provider does not use the Application to knowingly solicit data from or market to
    children under the age of 13.</p>
<div><br>
    <p>The Application does not address anyone under the age of 13. The Service Provider does not
        knowingly collect personally identifiable information from children under 13 years of age.
        In the case the Service Provider discover that a child under 13 has provided personal
        information, the Service Provider will immediately delete this from their servers. If you
        are a parent or guardian and you are aware that your child has provided us with personal
        information, please contact the Service Provider (fakhrymubarak@gmail.com) so that they will
        be able to take the necessary actions.</p></div><!----><br><strong>How is your information
    kept secure?</strong>
<p>The Service Provider are concerned about safeguarding the confidentiality of your information.
    The Service Provider provide physical, electronic, and procedural safeguards to protect
    information we process and maintain. For example, we limit access to this information to
    authorized employees and contractors who need to know that information in order to operate,
    develop or improve their Application. Please be aware that, although we endeavor provide
    reasonable security for information we process and maintain, no security system can prevent all
    potential security breaches.</p><br><strong>How will you be informed of changes to this Privacy
    Policy?</strong>
<p>This Privacy Policy may be updated from time to time for any reason. The Service Provider will
    notify you of any changes to the Privacy Policy by updating this page with the new Privacy
    Policy. You are advised to consult this Privacy Policy regularly for any changes, as continued
    use is deemed approval of all changes.</p><br>
<p>This privacy policy is effective as of 2025-12-16</p><br><strong>How do you give your
    consent?</strong>
<p>By using the Application, you are giving your consent to the Service Provider processing of your
    information as set forth in this Privacy Policy now and as amended by us. "Processing," means
    using cookies on a computer/hand held device or using or touching information in any way,
    including, but not limited to, collecting, storing, deleting, using, combining and disclosing
    information.</p><br><strong>How can you contact us?</strong>
<p>If you have any questions regarding privacy while using the Application, or have questions about
    the practices, please contact the Service Provider via email at fakhrymubarak@gmail.com.</p>
<hr>
<p>This privacy policy page was generated by <a
        href="https://app-privacy-policy-generator.nisrulz.com/" target="_blank"
        rel="noopener noreferrer">App Privacy Policy Generator</a></p>
</div>`,l=()=>e.jsxs(e.Fragment,{children:[e.jsx(o,{title:"Privacy Policy - PomoDojo",description:"Privacy policy for the PomoDojo - Pomodoro Timer application.",url:"https://fakhrymubarak.github.io/pomodojo/privacy"}),e.jsx("div",{className:"pomo-legal",dangerouslySetInnerHTML:{__html:i}})]});export{l as default};
