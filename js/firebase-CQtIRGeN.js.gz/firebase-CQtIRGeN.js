import{r as a,g as e,i as s}from"./index-DPBHTT04.js";import"./chunk-DavUf6mE.js";import"./chunk-LMjOszCr.js";import"./chunk-K44iAZUK.js";var r="firebase",i="12.1.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */a(r,i,"app");const o={apiKey:"AIzaSyCSR2TiaMwWx-NY9BVpHM2PbxannEBzlNU",authDomain:"fakhry-showcase-v2.firebaseapp.com",projectId:"fakhry-showcase-v2",storageBucket:"fakhry-showcase-v2.firebasestorage.app",messagingSenderId:"686700373210",appId:"1:686700373210:web:5b9c63f4e214511ae171e3",measurementId:"G-29VSW7CMFR"},p=s(o),f=e(p);export{f as analytics};
